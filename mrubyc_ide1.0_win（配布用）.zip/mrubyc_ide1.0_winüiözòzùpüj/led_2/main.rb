while true
  led 1
  sleep_ms 100
  led 0
  sleep_ms 100
end
