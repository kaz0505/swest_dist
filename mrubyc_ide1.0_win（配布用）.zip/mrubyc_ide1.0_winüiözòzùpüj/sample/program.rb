while true
  led 1
  sleep_ms 2
  led 0
  sleep_ms 6
end
